import { deserialModule, TypeTag, Type, FieldsTag } from '../src/deserializeSchema';
import { getDeserializedModule } from '../src/passSchema';

test('retrieve information about a given smart contract instance', async () => {

    var result = getDeserializedModule('/home/omkarsunku/Downloads/schema_RUST_btreemap_format.bin');
    console.log(result);
    var contractName = result["UsersFullDetails"].init;
    console.log(contractName);
    if (contractName?.typeTag === TypeTag.Struct) {
        console.log(contractName.fields)
        console.log(contractName.fields.fieldsTag)
        if (contractName.fields.fieldsTag == FieldsTag.Named) {
            for (let i = 0; i < contractName.fields.contents.length; i++) {
                for (let j = 0; j < contractName.fields.contents[i].length; j++) {
                   // console.log('i', i, 'j:', j, contractName.fields.contents[i][j]);

                    if (j == 1) {
                        console.log('i1', i, 'j1:', j, contractName.fields.contents[i][1])
                    }

                }
                let userProperties = contractName.fields.contents[i][0];
                console.log(userProperties)
            }
            // console.log(contractName.fields.contents[0])
            // console.log(contractName.fields.contents[0][0])
            // console.log(contractName.fields.contents[1][0])
            // console.log(contractName.fields.contents[2][0])
            // console.log(contractName.fields.contents[3][0])
            // console.log(contractName.fields.contents[4][0])
            
        }
    }

    //ARRAY 
    // var result = getDeserializedModule('/home/omkarsunku/concordium-rust-smart-contracts/examples/piggy-bank/part6/schema.bin');
    // console.log(result);
    // console.log(result["INDBankU83"].init);
    // var res:Type = result['INDBankU83'].receive["insertAmount"];
    // if (result["INDBankU83"].init?.typeTag == TypeTag.Array) {
    //     console.log(result["INDBankU83"].init.size);
    // } else {
    //     // fail the test
    // }
    // console.log(res);
    // console.log(result['INDBankU83'].receive["insertAmount1"]);
    // console.log(result['INDBankU83'].receive["insertAmount2"]);
    // console.log(result['INDBankU83'].receive["insertAmount3"]);
    // console.log(result['INDBankU83'].receive["insertAmount4"]);
    // console.log(result['INDBankU83'].receive["insertAmount5"]);
    // console.log(result['INDBankU83'].receive['insertAmount'].typeTag);
    //const stream = fs.createReadStream('/home/omkarsunku/Downloads/schema_RUST_btreemap_format.bin');
    // const stream = fs.createReadStream('/home/omkarsunku/concordium-rust-smart-contracts/examples/piggy-bank/part6/schema.bin');
    // stream.on('readable', async () => {
    //     const schema = deserialModule(stream);
    //     let type = "init";
    //     let contractName = "INDBankU83";
    //     console.log(schema["INDBankU83"].init);

    //     let getSchemeJSON = (type === 'init') ? schema[contractName].init : schema[contractName].receive;
    //     let getSchemeJSON1 = (type === 'receive') ? schema[contractName].init : schema[contractName].receive;
    //     console.log(getSchemeJSON);
    //     console.log(getSchemeJSON1);
    //     // console.log(schema.UsersFullDetails.state);
    //     // console.log(schema.UsersFullDetails.init?.typeTag); // could not fetch
    //     // console.log(schema.UsersFullDetails.receive); 
    //     // console.log(schema.UsersFullDetails.receive.insertAmount); 

    //     stream.destroy();
    // });
})