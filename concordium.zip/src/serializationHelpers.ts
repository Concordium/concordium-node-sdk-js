import { Buffer } from 'buffer/';
import { VerifyKey } from '.';
import {
    ParameterType,
    SMParameter,
    SMStruct,
    SMArray,
    SMTypes,
    SMPrimitiveTypes,
    ContractAddress,
    SchemaJsonType,
} from './types';
import { Memo } from './types/Memo';
import { AccountAddress } from './types/accountAddress';
import { GtuAmount } from '../src/types/gtuAmount';
import { FieldsTag, Module, Type, TypeTag } from './deserializeSchema';
const MAX_UINT_64 = 2n ** 64n - 1n; // 2^64 - 1
export function serializeMap<K extends string | number | symbol, T>(
    map: Record<K, T>,
    encodeSize: (size: number) => Buffer,
    encodeKey: (k: string) => Buffer,
    encodeValue: (t: T) => Buffer
): Buffer {
    const keys = Object.keys(map);
    const buffers = [encodeSize(keys.length)];
    keys.forEach((key) => {
        buffers.push(encodeKey(key));
        buffers.push(encodeValue(map[key as K]));
    });
    return Buffer.concat(buffers);
}

export function serializeList<T>(
    list: T[],
    putSize: (size: number) => Buffer,
    putMember: (t: T) => Buffer
): Buffer {
    const buffers = [putSize(list.length)];
    list.forEach((member: T) => {
        buffers.push(putMember(member));
    });
    return Buffer.concat(buffers);
}

/**
 * Encodes a 128 bit signed integer to a Buffer using big endian.
 * @param value a 128 bit integer
 * @returns big endian serialization of the input
 */
export function encodeInt128(value: bigint): Buffer {
    if (value > -18446744073709551616n || value < 18446744073709551615n) {
        throw new Error(
            'The input has to be a 128 bit signed integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(32);
    const view = new DataView(arr);
    const byteOffset = 4;
    const res = splitUInt128toUInt64(value);
    view.setBigInt64(byteOffset, res.left);
    view.setBigInt64(byteOffset + 8, res.right);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a 128 bit unsigned integer to a Buffer using big endian.
 * @param value a 128 bit integer
 * @returns big endian serialization of the input
 */
export function encodeWord128(value: bigint): Buffer {
    if (value > 170141183460469231731687303715884105728n || value < 0n) {
        throw new Error(
            'The input has to be a 128 bit unsigned integer but it was: ' +
            value
        );
    }
    const arr = new ArrayBuffer(32);
    const view = new DataView(arr);
    const byteOffset = 4;
    const res = splitUInt128toUInt64(value);
    view.setBigUint64(byteOffset, res.left);
    view.setBigUint64(byteOffset + 8, res.right);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a 64 bit signed integer to a Buffer using big endian.
 * @param value a 64 bit integer
 * @returns big endian serialization of the input
 */
export function encodeInt64(value: bigint): Buffer {
    if (value > 4294967295n || value < -4294967296n) {
        throw new Error(
            'The input has to be a 64 bit signed integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(8);
    const view = new DataView(arr);
    view.setBigInt64(0, value, false);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a boolean to a Buffer using big endian.
 * @param value a boolean value
 * @returns boolean serialization of the input
 */
export function encodeBool(value: boolean): Buffer {
    const result = value === true ? 1 : 0;
    const arr = new ArrayBuffer(1);
    const view = new DataView(arr);
    view.setInt8(0, result);
    return Buffer.from(new Int8Array(arr));
}

/**
 * Encodes a 64 bit unsigned integer to a Buffer using big endian.
 * @param value a 64 bit integer
 * @returns big endian serialization of the input
 */
export function encodeWord64(value: bigint): Buffer {
    if (value > 9223372036854775807n || value < 0n) {
        throw new Error(
            'The input has to be a 64 bit unsigned integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(8);
    const view = new DataView(arr);
    view.setBigUint64(0, value, false);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a 32 bit signed integer to a Buffer using big endian.
 * @param value a 32 bit integer
 * @returns big endian serialization of the input
 */
export function encodeInt32(value: number): Buffer {
    if (value > -2147483648 || value < 2147483647 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 32 bit signed integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(4);
    const view = new DataView(arr);
    view.setInt32(0, value, false);
    return Buffer.from(new Int8Array(arr));
}

/**
 * Encodes a 32 bit unsigned integer to a Buffer using little endian.
 * @param value a 32 bit integer
 * @useLittleEndian a boolean value false to use big endian else little endian.
 * @returns big endian serialization of the input
 */
export function encodeWord32(value: number, useLittleEndian = false): Buffer {
    if (value > 4294967295 || value < 0 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 32 bit unsigned integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(4);
    const view = new DataView(arr);
    view.setUint32(0, value, useLittleEndian);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a 16 bit signed integer to a Buffer using big endian.
 * @param value a 16 bit integer
 * @returns big endian serialization of the input
 */
export function encodeInt16(value: number): Buffer {
    if (value > -32768 || value < 32767 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 16 bit signed integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(2);
    const view = new DataView(arr);
    view.setInt16(0, value, false);
    return Buffer.from(new Int8Array(arr));
}

/**
 * Encodes a 16 bit unsigned integer to a Buffer using big endian.
 * @param value a 16 bit integer
 * @returns big endian serialization of the input
 */
export function encodeWord16(value: number): Buffer {
    if (value > 65535 || value < 0 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 16 bit unsigned integer but it was: ' + value
        );
    }
    const arr = new ArrayBuffer(2);
    const view = new DataView(arr);
    view.setUint16(0, value, false);
    return Buffer.from(new Uint8Array(arr));
}

/**
 * Encodes a 8 bit signed integer to a Buffer using big endian.
 * @param value a 8 bit integer
 * @returns big endian serialization of the input
 */
export function encodeInt8(value: number): Buffer {
    if (value > 127 || value < -128 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 8 bit signed integer but it was: ' + value
        );
    }

    return Buffer.from(Buffer.of(value));
}

/**
 * Encodes a 8 bit unsigned integer to a Buffer using big endian.
 * @param value a 8 bit integer
 * @returns big endian serialization of the input
 */
export function encodeWord8(value: number): Buffer {
    if (value > 255 || value < 0 || !Number.isInteger(value)) {
        throw new Error(
            'The input has to be a 8 bit unsigned integer but it was: ' + value
        );
    }
    return Buffer.from(Buffer.of(value));
}

export function encodeWord8FromString(value: string): Buffer {
    return encodeWord8(Number(value));
}

/**
 * Encodes a memo.
 * @param memo Memo containing the memo bytes.
 * @returns Buffer containing the length of the memo bytes and the memo bytes.
 */
export function encodeMemo(memo: Memo): Buffer {
    const length = encodeWord16(memo.memo.length);
    return Buffer.concat([length, memo.memo]);
}

/**
 * Packing a buffer along with its length in 64 bits
 * @param buffer
 * @returns Buffer containing the 64 bit length of buffer and buffer.
 */
export function packBufferWithWord64Length(buffer: Buffer): Buffer {
    const length = encodeWord64(BigInt(buffer.length));
    return Buffer.concat([length, buffer]);
}

/**
 * Packing a buffer along with its length in 32 bits
 * @param buffer
 * @useLittleEndian a boolean value false to use big endian else little endian.
 * @returns Buffer containing the 32 bit length of buffer and buffer.
 */
export function packBufferWithWord32Length(
    buffer: Buffer,
    useLittleEndian = false
): Buffer {
    const length = encodeWord32(buffer.length, useLittleEndian);
    return Buffer.concat([length, buffer]);
}

/**
 * Packing a buffer along the with offset of 16 bit length
 * @param buffer containing the buffer
 * @returns Buffer containing the length of the buffer of 16 bit and buffer.
 */
export function packBufferWithWord16Length(buffer: Buffer): Buffer {
    const length = encodeWord16(buffer.length);
    return Buffer.concat([length, buffer]);
}

/**
 * Convert string to byte array
 * @param utf-8 string
 * @returns Buffer
 */
export function encodeStringToByteArray(str: string): Buffer {
    const buffer = new Buffer(str, 'utf8');
    const length = encodeWord16(buffer.length);
    return Buffer.concat([length, buffer]);
}

enum SchemeId {
    Ed25519 = 0,
}

/**
 * Serializes a public key. The serialization includes the
 * scheme used for the key/
 * @param key the key to serialize
 * @returns the serialization of the key
 */
export function serializeVerifyKey(key: VerifyKey): Buffer {
    const scheme = key.schemeId as keyof typeof SchemeId;
    let schemeId;
    if (SchemeId[scheme] !== undefined) {
        schemeId = SchemeId[scheme];
    } else {
        throw new Error(`Unknown key type: ${scheme}`);
    }
    const keyBuffer = Buffer.from(key.verifyKey, 'hex');
    const serializedScheme = encodeWord8(schemeId);
    return Buffer.concat([serializedScheme, keyBuffer]);
}

/**
 * Serializes a year and month string.
 * @param yearMonth year and month formatted as "YYYYMM"
 * @returns the serialization of the year and month string
 */
export function serializeYearMonth(yearMonth: string): Buffer {
    const year = parseInt(yearMonth.substring(0, 4), 10);
    const month = parseInt(yearMonth.substring(4, 6), 10);
    const serializedYear = encodeWord16(year);
    const serializedMonth = encodeWord8(month);
    return Buffer.concat([serializedYear, serializedMonth]);
}

/**
 * @param bigint bigint value that need to be splitted
 * @returns two bigint values
 */
function splitUInt128toUInt64(bigint: bigint): {
    left: bigint;
    right: bigint;
} {
    return {
        left: (bigint & (MAX_UINT_64 << 64n)) >> 64n,
        right: bigint & MAX_UINT_64,
    };
}

/**
 *Check whether the type is fixed length
 * @param {ParameterType} type type of parameter
 * @returns {boolean} return true if the type is fixed length
 */
function isFixedType(type: ParameterType): boolean {
    return (
        type == ParameterType.U8 ||
        type == ParameterType.I8 ||
        type == ParameterType.U16 ||
        type == ParameterType.I16 ||
        type == ParameterType.U32 ||
        type == ParameterType.I32 ||
        type == ParameterType.U64 ||
        type == ParameterType.I64 ||
        type == ParameterType.U128 ||
        type == ParameterType.I128 ||
        type == ParameterType.Bool ||
        type == ParameterType.AccountAddress ||
        type == ParameterType.ContractAddress ||
        type == ParameterType.Amount ||
        type == ParameterType.Timestamp ||
        type == ParameterType.Duration ||
        type == ParameterType.Array ||
        type == ParameterType.Struct
    );
}

/**
 *Check whether the type is fixed length
 * @param {ParameterType} type type of parameter
 * @returns {boolean} return true if the type is fixed length
 */
function checkFixedType(type: TypeTag | undefined): boolean {
    return (
        type == TypeTag.U8 ||
        type == TypeTag.I8 ||
        type == TypeTag.U16 ||
        type == TypeTag.I16 ||
        type == TypeTag.U32 ||
        type == TypeTag.I32 ||
        type == TypeTag.U64 ||
        type == TypeTag.I64 ||
        type == TypeTag.U128 ||
        type == TypeTag.I128 ||
        type == TypeTag.Bool ||
        type == TypeTag.AccountAddress ||
        type == TypeTag.ContractAddress ||
        type == TypeTag.Amount ||
        type == TypeTag.Timestamp ||
        type == TypeTag.Duration ||
        type == TypeTag.String
    ); TypeTag
}

/**
 * @param parameter is array of parameters provided by the user
 * @returns Buffer of parameters
 */
export function serializeParameter(parameter: SMParameter<SMTypes>): Buffer {
    switch (parameter.type) {
        case ParameterType.U8:
            return encodeWord8((parameter as SMParameter<number>).value);
        case ParameterType.I8:
            return encodeInt8((parameter as SMParameter<number>).value);
        case ParameterType.U16:
            return encodeWord16((parameter as SMParameter<number>).value);
        case ParameterType.I16:
            return encodeInt16((parameter as SMParameter<number>).value);
        case ParameterType.U32:
            return encodeWord32((parameter as SMParameter<number>).value);
        case ParameterType.I32:
            return encodeInt32((parameter as SMParameter<number>).value);
        case ParameterType.U64:
            return encodeWord64((parameter as SMParameter<bigint>).value);
        case ParameterType.I64:
            return encodeInt64((parameter as SMParameter<bigint>).value);
        case ParameterType.U128:
            return encodeWord128((parameter as SMParameter<bigint>).value);
        case ParameterType.I128:
            return encodeInt128((parameter as SMParameter<bigint>).value);
        case ParameterType.Bool:
            return encodeBool((parameter as SMParameter<boolean>).value);
        case ParameterType.String:
            const stringParameter = (parameter as SMParameter<string>).value;
            const bufferValue = Buffer.from(stringParameter);
            return bufferValue;
        case ParameterType.AccountAddress:
            return (parameter as SMParameter<AccountAddress>).value
                .decodedAddress;
        case ParameterType.Amount:
            return encodeWord64(
                (parameter as SMParameter<GtuAmount>).value.microGtuAmount
            );
        case ParameterType.Timestamp:
            return encodeWord128((parameter as SMParameter<bigint>).value);
        case ParameterType.Duration:
            return encodeWord128((parameter as SMParameter<bigint>).value);
        case ParameterType.ContractAddress:
            const serializeIndex = encodeWord64(
                (parameter as SMParameter<ContractAddress>).value.index
            );
            const serializeSubIndex = encodeWord64(
                (parameter as SMParameter<ContractAddress>).value.subindex
            );
            return Buffer.concat([serializeIndex, serializeSubIndex]);
        case ParameterType.Struct:
            const bufferStruct: Buffer[] = [];
            (parameter.value as SMStruct).forEach((element) => {
                const parameterBuffer = serializeParameter(element);
                if (isFixedType(element.type)) {
                    bufferStruct.push(parameterBuffer);
                } else {
                    bufferStruct.push(
                        packBufferWithWord32Length(parameterBuffer, true)
                    );
                }
            });
            return Buffer.concat(bufferStruct);
        case ParameterType.Array:
            const bufferArray: Buffer[] = [];
            const arrayType = (
                parameter.value as SMArray<SMPrimitiveTypes | SMStruct>
            ).type;
            (
                parameter.value as SMArray<SMPrimitiveTypes | SMStruct>
            ).value.forEach((element) => {
                const parameterBuffer = serializeParameter({
                    type: arrayType,
                    value: element,
                });

                if (isFixedType(arrayType)) {
                    bufferArray.push(parameterBuffer);
                } else {
                    bufferArray.push(
                        packBufferWithWord32Length(parameterBuffer, true)
                    );
                }
            });
            return Buffer.concat(bufferArray);
        case ParameterType.Pair:
        case ParameterType.List:
        case ParameterType.Set:
        case ParameterType.Map:
        case ParameterType.Enum:
        case ParameterType.ContractName:
        case ParameterType.ReceiveName:
        case ParameterType.Unit:
            throw new Error("This type is not supported currently.");
        default:
            return Buffer.from([]);
    }
}


/**
 * Serialize the parameters for update contract
 * @userinput user input as json format
 * @contractName contract name to serialize
 * @receiveFunctionName receive function name to serialize
 */
export function serializeUpdateContractParameters(schemeJson: Module, userInput: string, contractName: string, receiveFunctionName: string): Buffer {
    let receiveFunctionScheme = schemeJson[contractName].receive[receiveFunctionName];
    let receiveSchemaType: TypeTag = TypeTag.U8;
    if (receiveFunctionScheme?.typeTag !== undefined) {
        receiveSchemaType = receiveFunctionScheme?.typeTag;
    }
    switch (checkFixedType(receiveFunctionScheme.typeTag)) {
        case true:
            //serializeSimpleTypes(receiveSchemaType, userInput);
            serializeParameter({
                type: TypeTag[receiveSchemaType],
                value: element,
            })
        case false:
            switch (receiveSchemaType) {
                case TypeTag.Struct:
                    const bufferStruct: Buffer[] = [];
                    if (receiveFunctionScheme?.typeTag === TypeTag.Struct) {
                        if (receiveFunctionScheme.fields.fieldsTag == FieldsTag.Named) {
                            for (let i = 0; i < receiveFunctionScheme.fields.contents.length; i++) {
                                // index 0 has the schema property used to fetch the userInputJson
                                let schemaProperty = receiveFunctionScheme.fields.contents[i][0];
                                let userValue;
                                for (let j = 0; j < receiveFunctionScheme.fields.contents[i].length; j++) {
                                    if (j == 1) {
                                        if (checkFixedType(receiveFunctionScheme.fields.contents[i][1].typeTag)) {
                                            let structType = receiveFunctionScheme.fields.contents[i][1].typeTag;
                                            userValue = JSON.stringify({ value: JSON.parse(userInput).value[schemaProperty] });
                                            bufferStruct.push(serializeSimpleTypes(structType, userValue));
                                        } else if (receiveFunctionScheme.fields.contents[i][1]?.typeTag === TypeTag.Array) {
                                            let array1 = receiveFunctionScheme.fields.contents[i][1];
                                            if (array1.typeTag === TypeTag.Array) {
                                                let size = array1.size;
                                                let arrayType = array1.of.typeTag;
                                                let userArrayValues = JSON.parse(JSON.stringify({ value: JSON.parse(userInput).value[schemaProperty] }));
                                                bufferStruct.push(serializeArray(size, arrayType, userArrayValues));
                                            }
                                        }
                                    }
                                }
                            }
                            return Buffer.concat(bufferStruct);
                        }
                    }
                case TypeTag.Array:
                    if (receiveSchemaType === TypeTag.Array) {
                        let arraySchema = receiveFunctionScheme;
                        if (arraySchema.typeTag === TypeTag.Array) {
                            let size = arraySchema.size;
                            let arrayType = arraySchema.of.typeTag;
                            let userArrayValues = JSON.parse(userInput);
                            console.log(userArrayValues);
                            return serializeArray(size, arrayType, userArrayValues);
                        }
                    }
                case TypeTag.Pair:
                case TypeTag.List:
                case TypeTag.Set:
                case TypeTag.Map:
                case TypeTag.Enum:
                case TypeTag.ContractName:
                case TypeTag.ReceiveName:
                case TypeTag.Unit:
                    throw new Error("This type is not supported currently.");
            }
    }

    return Buffer.from([]);
}

/**
 * Serialize init contract parameters
 * @param schemeJson contract schema
 * @param userInput user input in json format
 * @param contractName contract name to init contract parameters to be contructed
 * @returns a buffer format of the init contract parameters
 */
export function serializeInitContractParameters(schemeJson: Module, userInput: string, contractName: string): Buffer {
    let getSchemeJSON = schemeJson[contractName].init;
    let initSchemaType: TypeTag = TypeTag.U8;
    if (getSchemeJSON?.typeTag !== undefined) {
        initSchemaType = getSchemeJSON?.typeTag;
    }
    switch (checkFixedType(initSchemaType)) {
        case true:
            serializeSimpleTypes(initSchemaType, userInput);
        case false:
            switch (initSchemaType) {
                case TypeTag.Array:
                    if (getSchemeJSON?.typeTag === TypeTag.Array) {
                        let size = getSchemeJSON.size;
                        let arrayType = getSchemeJSON.of.typeTag;
                        let userArrayValues = JSON.parse(userInput);
                        return serializeArray(size, arrayType, userArrayValues);
                    }
                case TypeTag.Struct:
                    const bufferStruct: Buffer[] = [];
                    if (getSchemeJSON?.typeTag === TypeTag.Struct) {
                        if (getSchemeJSON.fields.fieldsTag == FieldsTag.Named) {
                            for (let i = 0; i < getSchemeJSON.fields.contents.length; i++) {
                                // index 0 has the schema property used to fetch the userInputJson
                                let schemaProperty = getSchemeJSON.fields.contents[i][0];
                                console.log(schemaProperty)
                                let userValue;
                                for (let j = 0; j < getSchemeJSON.fields.contents[i].length; j++) {
                                    //two
                                    if (j == 1) {
                                        if (checkFixedType(getSchemeJSON.fields.contents[i][1].typeTag)) {
                                            let structType = getSchemeJSON.fields.contents[i][1].typeTag;
                                            userValue = JSON.stringify({ value: JSON.parse(userInput).value[schemaProperty] });
                                            bufferStruct.push(serializeSimpleTypes(structType, userValue));
                                        } else if (getSchemeJSON.fields.contents[i][1]?.typeTag === TypeTag.Array) {
                                            let array1 = getSchemeJSON.fields.contents[i][1];
                                            if (array1.typeTag === TypeTag.Array) {
                                                let size = array1.size;
                                                let arrayType = array1.of.typeTag;
                                                let userArrayValues = JSON.parse(JSON.stringify({ value: JSON.parse(userInput).value[schemaProperty] }));
                                                bufferStruct.push(serializeArray(size, arrayType, userArrayValues));
                                            }
                                        }
                                    }
                                }
                            }
                            return Buffer.concat(bufferStruct);
                        }
                    }
                case TypeTag.Pair:
                case TypeTag.List:
                case TypeTag.Set:
                case TypeTag.Map:
                case TypeTag.Enum:
                case TypeTag.ContractName:
                case TypeTag.ReceiveName:
                case TypeTag.Unit:
                    throw new Error("This type is not supported currently.");
            }
        default:
            return Buffer.from([]);
    }


}

/**
 * serializeSimpleTypes like U8, U16, U32, U64 etc...
 * @param type type of the serialized type to
 * @param userInput user input
 * @returns Buffer format of the given type and user input
 */
export function serializeSimpleTypes(type: TypeTag, userInput: string): Buffer {
    let userInputJson = JSON.parse(userInput);
    switch (type) {
        case TypeTag.U8:
            return encodeWord8(userInputJson.value);
        case TypeTag.U16:
            return encodeWord16(userInputJson.value);
        case TypeTag.U32:
            return encodeWord32(userInputJson.value);
        case TypeTag.U64:
            return encodeWord64(userInputJson.value);
        case TypeTag.U128:
            return encodeWord128(userInputJson.value);
        case TypeTag.I8:
            return encodeInt8(userInputJson.value);
        case TypeTag.I16:
            return encodeInt16(userInputJson.value);
        case TypeTag.I32:
            return encodeInt32(userInputJson.value);
        case TypeTag.I64:
            return encodeInt64(userInputJson.value);
        case TypeTag.I128:
            return encodeInt128(userInputJson.value);
        case TypeTag.Bool:
            return encodeBool(userInputJson.value);
        case TypeTag.String:
            const stringParameter = userInputJson.value;
            const bufferValue = Buffer.from(stringParameter);
            return bufferValue;
        default:
            return Buffer.from([]);
    }
}

/**
 * Serialize array of parameters to Buffer
 * @param size array size
 * @param arrayType type of array
 * @param userArrayValues user input json
 * @returns serialize array of parameters to Buffer
 */
export function serializeArray(size: number, arrayType: TypeTag, userArrayValues: any): Buffer {
    console.log(userArrayValues.value)
    const bufferArray: Buffer[] = [];
    if (size === userArrayValues.value.length) {
        for (let i = 0; i < size; i++) {
            let userValue = JSON.stringify({ value: userArrayValues.value[i] });
            if (checkFixedType(arrayType)) {
                console.log('userValue', userValue);
                bufferArray.push(serializeSimpleTypes(arrayType, userValue))
            } else {
                bufferArray.push(
                    packBufferWithWord32Length(serializeSimpleTypes(arrayType, userValue), true)
                );
            }
        }
    }
    else {
        throw new Error("Array size and user input array not matched")
    }
    return Buffer.concat(bufferArray);
}


/**
 * convert TypeTag to string
 */
export function convertTypeTagToString(typeTag: TypeTag): string {
    return typeTag.toString();
}