import { AccountAddress, ContractAddress, GtuAmount } from '../src';
import { ModuleReference } from '../src/types/moduleReference';
import { getNodeClient } from './testHelpers';
import * as fs from 'fs';
import { BytesResponse } from '../grpc/concordium_p2p_rpc_pb';
const { TextEncoder, TextDecoder } = require('util');
const client = getNodeClient();

// test getInstanceInfo
test('retrieve information about a given smart contract instance', async () => {
    const blockHash =
        '31b7a1fe3f8a03acb52b50d95e129ece0ad41151248be801bf6aa5054a68e63b';
    const contractAddress: ContractAddress = {
        subindex: BigInt(0),
        index: BigInt(104),
    };
    const instanceInfo = await client.getInstanceInfo(
        blockHash,
        contractAddress
    );
    if (!instanceInfo) {
        throw new Error(
            'The instance info should exist for the provided block hash.'
        );
    }
    return Promise.all([
        expect(instanceInfo).not.toBe(null),
        expect(instanceInfo.amount).toStrictEqual(new GtuAmount(0n)),
        expect(instanceInfo.methods).toStrictEqual([
            'INDBankU81.insertAmount',
            'INDBankU81.smashAmount',
        ]),
        expect(Buffer.from('00', 'hex').equals(instanceInfo.model)).toBe(false),
        expect(instanceInfo.name).toBe('init_INDBankU81'),
        expect(instanceInfo.owner).toStrictEqual(
            new AccountAddress(
                '3gLPtBSqSi7i7TEzDPpcpgD8zHiSbWEmn23QZH29A7hj4sMoL5'
            )
        ),
        expect(instanceInfo.sourceModule).toStrictEqual(
            new ModuleReference(
                'fdea1e0404bc2f41cbe8d537abf6597e1a2872ef3d9f829729379cf89641ac76'
            )
        ),
    ]);
});

// test getInstances
test('retrieve all the smart contract instances at given block hash', async () => {
    const blockHash =
        '1729985f62c4070a8aed010fd0e5a76f6850bcc394eaf70bad517d93434f8822';

    const instances = await client.getInstances(blockHash);
    if (!instances) {
        throw new Error(
            'The instance info should exist for the provided block hash.'
        );
    }
    return Promise.all([
        expect(instances).not.toBe(null),
        expect(instances[0].index).toBe(0n),
        expect(instances[0].subindex).toBe(0n),
        expect(instances[1].index).toBe(1n),
        expect(instances[0].subindex).toBe(0n),
    ]);
});


test('retrieve all the smart contract instances at given block hash', async () => {
    const blockHash =
        'ec5c34dc16b4bb2a23832d50c7f670056477e4d960c1b38f2848f0f862e7ab43';

    const moduleReference =
        new ModuleReference('b7df7f72f1fec57682f3a49248b807f8e29b7eeb19548d6c66d42eadbb579e9b');

    const instances = await client.getModuleSource(blockHash, moduleReference);

    if (!instances) {
        throw new Error(
            'The instance info should exist for the provided block hash.'
        );
    }
    // largeuint8ArrToString(instances, function(text:any){
    //     // Hello
    console.log('text', instances);
    // });
    const module = BytesResponse.deserializeBinary(instances).getValue();
    console.log(new TextDecoder().decode(instances));
    fs.writeFileSync('/home/omkarsunku/Desktop/30122021_getModuleBuffer', Buffer.from(instances));
    fs.writeFileSync('/home/omkarsunku/Desktop/30122021_getModule', instances);
    fs.writeFileSync('/home/omkarsunku/Desktop/bytedecode', module);

    return Promise.all([

    ]);
});

/**
 * Convert an Uint8Array into a string.
 *
 * @returns {String}
 */
function Decodeuint8arr(uint8array: Uint8Array) {
    return new TextDecoder().decode(uint8array);
}
// http://www.onicos.com/staff/iz/amuse/javascript/expert/utf.txt

/* utf.js - UTF-8 <=> UTF-16 convertion
 *
 * Copyright (C) 1999 Masanao Izumo <iz@onicos.co.jp>
 * Version: 1.0
 * LastModified: Dec 25 1999
 * This library is free.  You can redistribute it and/or modify it.
 */

function Utf8ArrayToStr(array: Uint8Array) {
    var out, i, len, c;
    var char2, char3;

    out = "";
    len = array.length;
    i = 0;
    while (i < len) {
        c = array[i++];
        switch (c >> 4) {
            case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                // 0xxxxxxx
                out += String.fromCharCode(c);
                break;
            case 12: case 13:
                // 110x xxxx   10xx xxxx
                char2 = array[i++];
                out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
                break;
            case 14:
                // 1110 xxxx  10xx xxxx  10xx xxxx
                char2 = array[i++];
                char3 = array[i++];
                out += String.fromCharCode(((c & 0x0F) << 12) |
                    ((char2 & 0x3F) << 6) |
                    ((char3 & 0x3F) << 0));
                break;
        }
    }

    return out;
}