import { AccountAddress, ContractAddress, GtuAmount } from '../src';
import { ModuleReference } from '../src/types/moduleReference';
import { getNodeClient } from './testHelpers';
import * as fs from 'fs';
const { TextEncoder, TextDecoder } = require('util');
const client = getNodeClient();


test('retrieve all the smart contract instances at given block hash', async () => {
    const blockHash =
        'ec5c34dc16b4bb2a23832d50c7f670056477e4d960c1b38f2848f0f862e7ab43';

    const moduleReference =
        new ModuleReference('b7df7f72f1fec57682f3a49248b807f8e29b7eeb19548d6c66d42eadbb579e9b');

    const instances = await client.getModuleSource(blockHash, moduleReference);
    if (!instances) {
        throw new Error(
            'The instance info should exist for the provided block hash.'
        );
    }
    
    fs.writeFileSync('/home/omkarsunku/Desktop/source1712_2.bin', instances);

    return Promise.all([

    ]);
});

