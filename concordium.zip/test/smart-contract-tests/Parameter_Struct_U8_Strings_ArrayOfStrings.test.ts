import {
    AccountTransaction,
    AccountTransactionHeader,
    AccountTransactionSignature,
    AccountTransactionType,
    InitContractPayload,
    ParameterType,
    SMParameter,
    SMStruct,
} from '../../src/types';
import * as ed from 'noble-ed25519';
import { getAccountTransactionHash, getAccountTransactionSignDigest } from '../../src/serialization';
import { getNodeClient } from '../testHelpers';
import { AccountAddress } from '../../src/types/accountAddress';
import { GtuAmount } from '../../src/types/gtuAmount';
import { TransactionExpiry } from '../../src/types/transactionExpiry';
import { Buffer } from 'buffer/';
import { ModuleReference } from '../../src/types/moduleReference';
import { getContractSchemaString } from '../../src/getContractSchema';
import { convertTypeTagToString, serializeInitContractParameters } from '../../src/serializationHelpers';
import { deserialModuleFromBuffer } from '../../src/passSchema';
import { TypeTag } from '../../src/deserializeSchema';
const client = getNodeClient();
const senderAccountAddress =
    '3gLPtBSqSi7i7TEzDPpcpgD8zHiSbWEmn23QZH29A7hj4sMoL5';
const wrongPrivateKey =
    '681de9a98d274b56eace2f86eb134bfc414f5c366022f281335be0b2d45a8988';
// test case for init contract
test('Parameter of Struct parameter (Complex) the wrong private key', async () => {
    const nextAccountNonce = await client.getNextAccountNonce(
        new AccountAddress(senderAccountAddress)
    );
    if (!nextAccountNonce) {
        throw new Error('Nonce not found!');
    }
    const header: AccountTransactionHeader = {
        expiry: new TransactionExpiry(new Date(Date.now() + 3600000)),
        nonce: nextAccountNonce.nonce,
        sender: new AccountAddress(senderAccountAddress),
    };
    let str = TypeTag[TypeTag.Array];
    console.log(str);
    console.log(convertTypeTagToString(str));
    console.log(SMParameter))
const contractName = 'SampleContract1';
const userJson = {
    age: 27,
    name: 'Concordium',
    city: 'Zug',
    country: 'Concordium',
    nicknames: ['CCD', 'Concordium', 'GTU', 'NA']
};

const blockHash =
    '2e9cb10c8d1e13fb11511eeb04a6b194284a4fa8ef0fb22a9ef188c67bfe7ac7';

const moduleReference =
    new ModuleReference('dbd04be8563ab052d789a7eb7d72a9bf8bb605ad109a7adbe6d1b51340ac98d6');

const instances = await client.getModuleSource(blockHash, moduleReference);
const schemaStr = new TextDecoder('ascii').decode(instances);
const contractSchema = getContractSchemaString(schemaStr);
const scheme = deserialModuleFromBuffer(contractSchema);
const inputParams = serializeInitContractParameters(scheme, JSON.stringify(userJson), contractName);
const baseEnergy = 300000n;

const initModule: InitContractPayload = {
    amount: new GtuAmount(0n),
    moduleRef: new ModuleReference(
        'dbd04be8563ab052d789a7eb7d72a9bf8bb605ad109a7adbe6d1b51340ac98d6'
    ),
    contractName: contractName,
    parameter: inputParams,
    maxContractExecutionEnergy: baseEnergy,
} as InitContractPayload;

const initContractTransaction: AccountTransaction = {
    header: header,
    payload: initModule,
    type: AccountTransactionType.InitializeSmartContractInstance,
};

const hashToSign = getAccountTransactionSignDigest(initContractTransaction);
const signature = Buffer.from(
    await ed.sign(hashToSign, wrongPrivateKey)
).toString('hex');
const signatures: AccountTransactionSignature = {
    0: {
        0: signature,
    },
};

    // const result = await client.sendAccountTransaction(
    //     initContractTransaction,
    //     signatures
    // );
    // const txHash = await getAccountTransactionHash(
    //     initContractTransaction,
    //     signatures
    // );
    // console.log(txHash);
    // expect(result).toBeTruthy();
}, 300000);