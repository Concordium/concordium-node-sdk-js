import {
    AccountTransaction,
    AccountTransactionHeader,
    AccountTransactionSignature,
    AccountTransactionType,
    UpdateContractPayload,
    ContractAddress,
    ParameterType,
    SMParameter,
} from '../../src/types';
import * as ed from 'noble-ed25519';
import { getAccountTransactionHash, getAccountTransactionSignDigest } from '../../src/serialization';
import { getNodeClient } from '../testHelpers';
import { AccountAddress } from '../../src/types/accountAddress';
import { GtuAmount } from '../../src/types/gtuAmount';
import { TransactionExpiry } from '../../src/types/transactionExpiry';
import { Buffer } from 'buffer/';
import { serializeUpdateContractParameters } from '../../src/serializationHelpers';
import { deserialModuleFromBuffer } from '../../src/passSchema';
import { ModuleReference } from '../../src/types/moduleReference';
import { getContractSchemaString} from '../../src/getContractSchema';
var schemaJson = require('./sampleSchema.json');
const client = getNodeClient();
const senderAccountAddress =
    '3gLPtBSqSi7i7TEzDPpcpgD8zHiSbWEmn23QZH29A7hj4sMoL5';
const wrongPrivateKey =
    '681de9a98d274b56eace2f86eb134bfc414f5c366022f281335be0b2d45a8988';

//test case for update contract
test('Parameter of I8 with the wrong private key', async () => {
    const nextAccountNonce = await client.getNextAccountNonce(
        new AccountAddress(senderAccountAddress)
    );
    if (!nextAccountNonce) {
        throw new Error('Nonce not found!');
    }
    const header: AccountTransactionHeader = {
        expiry: new TransactionExpiry(new Date(Date.now() + 3600000)),
        nonce: nextAccountNonce.nonce,
        sender: new AccountAddress(senderAccountAddress),
    };

    const receiveFunctionName = 'insertAmount';
    const contractName = 'SampleU8';
    const receiveName = contractName + '.' + receiveFunctionName;

    // const userJson = {
    //     "value": { age: 26, name: "Omkar", "city": "Bangalore", country: "India", nicknames: ["sai", "tom", "om", "kanna"] },
    // };
    const userJson = { 
        value: 20
    }

    const blockHash =
        'ec5c34dc16b4bb2a23832d50c7f670056477e4d960c1b38f2848f0f862e7ab43';

    const moduleReference =
        new ModuleReference('b7df7f72f1fec57682f3a49248b807f8e29b7eeb19548d6c66d42eadbb579e9b');

    const instances = await client.getModuleSource(blockHash, moduleReference);
    const pdfStr = new TextDecoder('ascii').decode(instances);
    const contractSchema = getContractSchemaString(pdfStr);
    const scheme = deserialModuleFromBuffer(contractSchema);
    const inputParams = serializeUpdateContractParameters(scheme, JSON.stringify(userJson), contractName, receiveFunctionName);
    const contractAddress = {
        index: BigInt(108),
        subindex: BigInt(0),
    } as ContractAddress;
    const baseEnergy = 30000n;

    const updateModule: UpdateContractPayload = {
        amount: new GtuAmount(1000n),
        contractAddress: contractAddress,
        receiveName: receiveName,
        parameter: inputParams,
        maxContractExecutionEnergy: baseEnergy,
    } as UpdateContractPayload;

    const updateContractTransaction: AccountTransaction = {
        header: header,
        payload: updateModule,
        type: AccountTransactionType.UpdateSmartContractInstance,
    };

    const hashToSign = getAccountTransactionSignDigest(
        updateContractTransaction
    );
    const signature = Buffer.from(
        await ed.sign(hashToSign, wrongPrivateKey)
    ).toString('hex');
    const signatures: AccountTransactionSignature = {
        0: {
            0: signature,
        },
    };

    const result = await client.sendAccountTransaction(
        updateContractTransaction,
        signatures
    );

    const txHash = await getAccountTransactionHash(
        updateContractTransaction,
        signatures
    );
    console.log(txHash);
    expect(result).toBeTruthy();
}, 300000);
